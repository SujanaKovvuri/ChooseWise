package com.ts;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;


import com.dao.OrderDetailsDao;
import com.model.OrderDetails;


@RestController
public class OrderDetailsController {

	@Autowired
	OrderDetailsDao orderDetailsDao = new OrderDetailsDao();
	
	
	@PostMapping("/registerOrderDetails")
	public OrderDetails registerOrderDetails(@RequestBody OrderDetails orderDetails) {
		
		System.out.println("Recieved Register Order : "+orderDetails);
		return orderDetailsDao.registerOrderDetails(orderDetails);
		

	}


}