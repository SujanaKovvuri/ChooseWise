package com.ts;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dao.CustomerDao;
import com.dao.OrdersDao;
import com.model.Orders;

@RestController
public class OrdersController {
	@Autowired
	OrdersDao ordersDao = new OrdersDao();
	
	@Autowired
	CustomerDao customerDao = new CustomerDao();
	
	@PostMapping("/registerOrders")
	public Orders registerOrders(@RequestBody Orders orders) {

		return ordersDao.registerOrders(orders);

	}

}
