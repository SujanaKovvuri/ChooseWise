package com.ts;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dao.ProductDao;

import com.model.Product;

@RestController
public class ProductController {
	
	@Autowired
	ProductDao productDao;
	
	@PostMapping("/purchase")
	public void purchase(@RequestBody List<Product> items) {
	 productDao.purchase(items);
		
	}
	
	@PostMapping("/deleteReq")			
	public void delete(@RequestBody Product item){
		System.out.println(item);
		productDao.deleteRequest(item);
	}
	

}
