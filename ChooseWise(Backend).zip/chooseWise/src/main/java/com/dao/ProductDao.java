package com.dao;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.model.Product;

@Service
public class ProductDao {

	@Autowired
	ProductRepository productRepository;
	
	public void purchase(List<Product> items) {
		productRepository.saveAll(items); 
		 
		}
	 public void deleteRequest(Product item) {
	        productRepository.delete(item);
	    }
	
}
